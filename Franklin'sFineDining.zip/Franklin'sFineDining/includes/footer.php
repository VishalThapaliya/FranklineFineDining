				<div id="footer" class="cf">
					<div class="column three">
						<strong>Phone</strong>
						123.456.7890
					</div>
					<div class="column three">
						<strong>Location</strong>
						258 Rue De Stalingrad, Drancy.
					</div>
					<div class="column three last">
						<strong>Hours</strong>
						<em>Sunday - Saturday :</em><br>
						<em> 11:00 - 23:00</em>
					</div>
					
				</div><!-- end footer -->
				<small>&copy: <?php echo date('Y'); ?> | <?php echo $companyName; ?> </small>
			</div> <!-- end content -->
		</div><!-- end wrapper -->
		
	</body>
</html>